"""CWITools Libraries

This module contains generally useful methods divided categorically into a
few different libraries based on functionality.

"""
