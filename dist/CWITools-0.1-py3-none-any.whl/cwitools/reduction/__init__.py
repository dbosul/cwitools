"""Tools for correcting and coadding CWI cubes to produce a final stacked cube.
"""
import coadd
