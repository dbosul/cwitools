"""Tools for extracting and analyzing nebular emission in CWI data cubes."""

