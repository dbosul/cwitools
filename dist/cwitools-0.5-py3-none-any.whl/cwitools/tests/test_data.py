coadd_path = __file__.replace("test_data.py", "test_icubes.fits")
icubes_path = __file__.replace("test_data.py", "test_coadd.fits")
reg_path = __file__.replace("test_data.py", "test_reg.reg")
param_path = __file__.replace("tests/test_data.py", "template.param")
ra, dec, z = 149.689272107, 47.056788021, 2.491
