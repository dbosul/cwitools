CWITools Documentation on ReadTheDocs: https://cwitools.readthedocs.io/en/latest/


