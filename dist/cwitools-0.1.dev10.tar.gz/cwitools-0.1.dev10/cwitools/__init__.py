"""A data analysis kit for the Palomar and Keck Cosmic Web Imagers."""
